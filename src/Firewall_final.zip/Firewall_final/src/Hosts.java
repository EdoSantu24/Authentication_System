import java.util.List;

public class Hosts {
    private List<Host> hosts;

    // Getters and setters
    public List<Host> getHosts() {
        return hosts;
    }

    public void setHosts(List<Host> hosts) {
        this.hosts = hosts;
    }
}
