public class Device_old {

        private String id;
        private String type;
        private Boolean available;
        private String role;
        private String mfr;
        private String hw;
        private String sw;
        private String serial;
        private String chassisId;
        private Annotations annotations;

        /**
         *
         * @return
         * The id
         */
        public String getId() {
            return id;
        }

        /**
         *
         * @param id
         * The id
         */
        public void setId(String id) {
            this.id = id;
        }

        /**
         *
         * @return
         * The type
         */
        public String getType() {
            return type;
        }

        /**
         *
         * @param type
         * The type
         */
        public void setType(String type) {
            this.type = type;
        }

        /**
         *
         * @return
         * The available
         */
        public Boolean getAvailable() {
            return available;
        }

        /**
         *
         * @param available
         * The available
         */
        public void setAvailable(Boolean available) {
            this.available = available;
        }

        /**
         *
         * @return
         * The role
         */
        public String getRole() {
            return role;
        }

        /**
         *
         * @param role
         * The role
         */
        public void setRole(String role) {
            this.role = role;
        }

        /**
         *
         * @return
         * The mfr
         */
        public String getMfr() {
            return mfr;
        }

        /**
         *
         * @param mfr
         * The mfr
         */
        public void setMfr(String mfr) {
            this.mfr = mfr;
        }

        /**
         *
         * @return
         * The hw
         */
        public String getHw() {
            return hw;
        }

        /**
         *
         * @param hw
         * The hw
         */
        public void setHw(String hw) {
            this.hw = hw;
        }

        /**
         *
         * @return
         * The sw
         */
        public String getSw() {
            return sw;
        }

        /**
         *
         * @param sw
         * The sw
         */
        public void setSw(String sw) {
            this.sw = sw;
        }

        /**
         *
         * @return
         * The serial
         */
        public String getSerial() {
            return serial;
        }

        /**
         *
         * @param serial
         * The serial
         */
        public void setSerial(String serial) {
            this.serial = serial;
        }

        /**
         *
         * @return
         * The chassisId
         */
        public String getChassisId() {
            return chassisId;
        }

        /**
         *
         * @param chassisId
         * The chassisId
         */
        public void setChassisId(String chassisId) {
            this.chassisId = chassisId;
        }

        /**
         *
         * @return
         * The annotations
         */
        public Annotations getAnnotations() {
            return annotations;
        }

        /**
         *
         * @param annotations
         * The annotations
         */
        public void setAnnotations(Annotations annotations) {
            this.annotations = annotations;
        }

    }
