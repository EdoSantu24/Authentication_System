/**
 * Created by student on 07/10/20
 */

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Device implements Serializable
{

    private String id;
    private String type;
    private Boolean available;
    private String role;
    private String mfr;
    private String hw;
    private String sw;
    private String serial;
    private String driver;
    private String chassisId;
    private String lastUpdate;
    private String humanReadableLastUpdate;
    private Annotations annotations;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -2833944564654080263L;

    /**
     * No args constructor for use in serialization
     *
     */
    public Device() {
    }

    /**
     *
     * @param role
     * @param humanReadableLastUpdate
     * @param sw
     * @param available
     * @param annotations
     * @param type
     * @param hw
     * @param chassisId
     * @param driver
     * @param serial
     * @param lastUpdate
     * @param mfr
     * @param id
     */
    public Device(String id, String type, Boolean available, String role, String mfr, String hw, String sw, String serial, String driver, String chassisId, String lastUpdate, String humanReadableLastUpdate, Annotations annotations) {
        super();
        this.id = id;
        this.type = type;
        this.available = available;
        this.role = role;
        this.mfr = mfr;
        this.hw = hw;
        this.sw = sw;
        this.serial = serial;
        this.driver = driver;
        this.chassisId = chassisId;
        this.lastUpdate = lastUpdate;
        this.humanReadableLastUpdate = humanReadableLastUpdate;
        this.annotations = annotations;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getMfr() {
        return mfr;
    }

    public void setMfr(String mfr) {
        this.mfr = mfr;
    }

    public String getHw() {
        return hw;
    }

    public void setHw(String hw) {
        this.hw = hw;
    }

    public String getSw() {
        return sw;
    }

    public void setSw(String sw) {
        this.sw = sw;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public String getChassisId() {
        return chassisId;
    }

    public void setChassisId(String chassisId) {
        this.chassisId = chassisId;
    }

    public String getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(String lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getHumanReadableLastUpdate() {
        return humanReadableLastUpdate;
    }

    public void setHumanReadableLastUpdate(String humanReadableLastUpdate) {
        this.humanReadableLastUpdate = humanReadableLastUpdate;
    }

    public Annotations getAnnotations() {
        return annotations;
    }

    public void setAnnotations(Annotations annotations) {
        this.annotations = annotations;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

