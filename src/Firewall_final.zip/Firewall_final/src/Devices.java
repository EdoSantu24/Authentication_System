/**
 * Created by student on 07/10/20
 */
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Devices implements Serializable
{

    private List<Device> devices = null;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -8118599685145232753L;

    /**
     * No args constructor for use in serialization
     *
     */
    public Devices() {
    }

    /**
     *
     * @param devices
     */
    public Devices(List<Device> devices) {
        super();
        this.devices = devices;
    }

    public List<Device> getDevices() {
        return devices;
    }

    public void setDevices(List<Device> devices) {
        this.devices = devices;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

