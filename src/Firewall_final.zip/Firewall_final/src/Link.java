/**
 * Created by student on 12/7/16.
 */
public class Link {

    private Src src;
    private Dst dst;
    private String type;
    private String state;

    /**
     *
     * @return
     * The src
     */
    public Src getSrc() {
        return src;
    }

    /**
     *
     * @param src
     * The src
     */
    public void setSrc(Src src) {
        this.src = src;
    }

    /**
     *
     * @return
     * The dst
     */
    public Dst getDst() {
        return dst;
    }

    /**
     *
     * @param dst
     * The dst
     */
    public void setDst(Dst dst) {
        this.dst = dst;
    }

    /**
     *
     * @return
     * The type
     */
    public String getType() {
        return type;
    }

    /**
     *
     * @param type
     * The type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     *
     * @return
     * The state
     */
    public String getState() {
        return state;
    }

    /**
     *
     * @param state
     * The state
     */
    public void setState(String state) {
        this.state = state;
    }

}