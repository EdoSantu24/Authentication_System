/**
 * Created by student on 12/7/16.
 */


import java.util.List;

public class Links {

    private List<Link> links = null;

    /**
     *
     * @return
     * The links
     */
    public List<Link> getLinks() {
        return links;
    }

    /**
     *
     * @param links
     * The links
     */
    public void setLinks(List<Link> links) {
        this.links = links;
    }

}
