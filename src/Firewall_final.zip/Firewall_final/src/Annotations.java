/**
 * Created by student on 07/10/20
 */

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Annotations implements Serializable
{

    private String channelId;
    private String managementAddress;
    private String protocol;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 6378385279610038763L;

    /**
     * No args constructor for use in serialization
     *
     */
    public Annotations() {
    }

    /**
     *
     * @param managementAddress
     * @param protocol
     * @param channelId
     */
    public Annotations(String channelId, String managementAddress, String protocol) {
        super();
        this.channelId = channelId;
        this.managementAddress = managementAddress;
        this.protocol = protocol;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getManagementAddress() {
        return managementAddress;
    }

    public void setManagementAddress(String managementAddress) {
        this.managementAddress = managementAddress;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

