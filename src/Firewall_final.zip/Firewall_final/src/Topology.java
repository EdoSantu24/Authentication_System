
public class Topology {

    private long time;
    private Integer devices;
    private Integer links;
    private Integer clusters;
    /**
     * @return
     * The time
     */
    public long getTime() {
        return time;
    }
    /**
     * @param time
     * The time
     */
    public void setTime(long time) {
        this.time = time;
    }
    /**
     * @return
     * The devices
     */
    public Integer getDevices() {
        return devices;
    }
    /**
     * @param devices
     * The devices
     */
    public void setDevices(Integer devices) {
        this.devices = devices;
    }
    /**
     * @return
     * The links
     */
    public Integer getLinks() {
        return links;
    }
    /**
      * @param links
     * The links
     */
    public void setLinks(Integer links) {
        this.links = links;
    }
    /**
     * @return
     * The clusters
     */
    public Integer getClusters() {
        return clusters;
    }
    /**
     * @param clusters
     * The clusters
     */
    public void setClusters(Integer clusters) {
        this.clusters = clusters;
    }
}

