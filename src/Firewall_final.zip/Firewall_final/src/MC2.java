
//
// Checked and updated for REST API changes. Jan 2018. J. Soler
// The ONOS REST API in ONOS has changed and therefore it was necessary to create /recreate new POJOS and verify / modify target address (i.e. appID in POST)
//

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;


//

/**
 * Created by student on 12/2/16.
 */
public class MC2 {
    public static void main(String[] argv) {

        //Initial REST Service to test basis RS consumption of REST - Comment for PrintInfo example

        /*
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:8090/MyRS_war_exploded/helloworld");
        String reply = target.request("text/plain").get(String.class);
        System.out.println("Received reply: " + reply);
        */
        //
        //------             ----------------------------------------
        //
        // Initial REST invocation of ONOS REST API - Uncomment for printInfo example
        //


        Client client = ClientBuilder.newClient().register(new Authenticator("onos", "rocks"));
        WebTarget target = client.target("http://localhost:8181/onos/v1/topology");
        Response response = target.request().accept(MediaType.APPLICATION_JSON_TYPE).get();
        System.out.println(response.getStatus());
        System.out.println(response.toString());
        StringBuilder target_switch_for_URL=null;
        //
        // Mapping REST response content to own POJO - For quick POJO creation from JSON: www.jsonschema2pojo.org
        //
        Topology mytopo = response.readEntity(Topology.class);
        System.out.println("Topology timestamp: " + mytopo.getTime());
        System.out.println("Topology clusters: " + mytopo.getClusters().toString());
        System.out.println("Topology devices: " + mytopo.getDevices().toString());
        System.out.println("Topology links: " + mytopo.getLinks().toString());

        //
        // DO THE SAME FOR DEVICES
        List<String> switches = new ArrayList<>(); //creating switches list
        target = client.target("http://localhost:8181/onos/v1/devices");
        response = target.request().accept(MediaType.APPLICATION_JSON_TYPE).get();
        System.out.println(response.getStatus());
        Devices mydevices = response.readEntity(Devices.class);
        System.out.println("Number of Devices: " + String.valueOf(mydevices.getDevices().size()));
        System.out.println();
        for (Device mydevice : mydevices.getDevices()) {
            if ("SWITCH".equals(mydevice.getType())) {  // Only add switches to the list
                switches.add(mydevice.getId()); //list of the switches deviceIds
            }
            System.out.println("Device Id: " + mydevice.getId().toString());
            System.out.println("Device Type: " + mydevice.getType().toString());
            System.out.println("Device Availability: " + mydevice.getAvailable().toString());
            System.out.println("Device Role: " + mydevice.getRole().toString());
            System.out.println("Device MFR: " + mydevice.getType().toString());
            System.out.println("Device SW: " + mydevice.getSw().toString());
            System.out.println("Device HW: " + mydevice.getHw().toString());
            System.out.println("Device Serial: " + mydevice.getSerial().toString());
            System.out.println("Chasis ID: " + mydevice.getChassisId().toString());
            System.out.println("Device Annotation Management Address: " + mydevice.getAnnotations().getManagementAddress().toString());
            System.out.println("Device Annotation Protocol: " + mydevice.getAnnotations().getProtocol().toString());
            System.out.println("Device Annotation Channel Id: " + mydevice.getAnnotations().getChannelId().toString());
            System.out.println("-------------------------------------------- ");
        }

        // Fetch and print hosts information
        List<String> hostIPs = new ArrayList<>();
        // Map for host IP addresses to their associated elementId (switch ID)
        Map<String, String> hostIpToSwitchMap = new HashMap<>();  // Maps host IP to elementId (switch the host is connected)
        target = client.target("http://localhost:8181/onos/v1/hosts");
        response = target.request().accept(MediaType.APPLICATION_JSON_TYPE).get();
        System.out.println(response.getStatus());
        Hosts myhosts = response.readEntity(Hosts.class);
        System.out.println("Number of Hosts: " + myhosts.getHosts().size());
        for (Host myhost : myhosts.getHosts()) {
            System.out.println("Host ID: " + myhost.getId());
            System.out.println("Host MAC: " + myhost.getMac());
            System.out.println("Host VLAN: " + myhost.getVlan());
            System.out.println("Host IPs: " + myhost.getIpAddresses());
            // Add host IPs to the list
            for (String ip : myhost.getIpAddresses()) {
                hostIPs.add(ip);
            }
            // Location is important because it contains the elementID of the device (switch) the host is connected to
            // --> it can be useful to make the code work with any topology as input
            // I had to create a new pojo class: Location to manage the locations with parameters elementId and Port
            if (myhost.getLocations() != null) { //location is a list because each host can be connected to multiple devices
                System.out.println("Locations list size: " + myhost.getLocations().size()); //number of devices the host is connected to
                Location location = myhost.getLocations().get(0);
                hostIpToSwitchMap.putAll(mapHostToSwitch(myhost.getIpAddresses(), location.getElementId())); // Map all host IPs to their switch (elementId)
                System.out.println("Element ID: " + location.getElementId());
                System.out.println("Port: " + location.getPort());
            } else {
                System.out.println("Location is null for host " + myhost.getId());
            }
            System.out.println("-------------------------------------------- ");
        }

        //
        // DO THE SAME FOR LINKS
        //
        target = client.target("http://localhost:8181/onos/v1/links");
        response = target.request().accept(MediaType.APPLICATION_JSON_TYPE).get();
        System.out.println(response.getStatus());
        Links mylinks = response.readEntity(Links.class);
        System.out.println("Number of Links: " + String.valueOf(mylinks.getLinks().size()));
        System.out.println();

        for (Link mylink : mylinks.getLinks()) {
            System.out.println("Source:      Device " + mylink.getSrc().getDevice().toString() + " Port " + mylink.getSrc().getPort().toString());
            System.out.println("Destination: Device " + mylink.getDst().getDevice().toString() + " Port " + mylink.getDst().getPort().toString());
            System.out.println("Link Type: " + mylink.getType().toString());
            System.out.println("Link State: " + mylink.getState().toString());
            System.out.println("-------------------------------------------- ");

        }

        //
        //Firewall Part
        //

        StringBuilder targetSwitchForURL = null;

        // Print out the host to switch mapping (for debugging/verification)
        System.out.println("Host (IPs) to Switch (Ids) Mapping:");
        for (Map.Entry<String, String> entry : hostIpToSwitchMap.entrySet()) {
            System.out.println("Host with Ip Address: " + entry.getKey() + " is connected to Switch with Id: " + entry.getValue());
        }

        //APPLY RULES TO EVERY
        System.out.println("pushRule: Applying rules for all hosts.");
        // Client setup for ONOS REST API
        client = ClientBuilder.newClient().register(new Authenticator("onos", "rocks"));

        // Iterate over the host-to-switch map and apply rules dynamically
        for (Map.Entry<String, String> entry : hostIpToSwitchMap.entrySet()) {
            String srcHost = entry.getKey();  // Host IP (key)
            String targetSwitch = entry.getValue();  // Switch ID the host is connected to (elementId, value)

            // Format the target switch for ONOS REST API
            targetSwitchForURL = new StringBuilder(targetSwitch);
            targetSwitchForURL.delete(2, 3); // Replace ":" with "%3A"
            targetSwitchForURL.insert(2, "%3A");

            // Iterate over destination hosts (which could be any host in the topology)
            for (Map.Entry<String, String> dstEntry : hostIpToSwitchMap.entrySet()) {
                String dstHost = dstEntry.getKey();
                if (!srcHost.equals(dstHost)) { // Skip rules for the same source and destination host
                    // Prepare forward rule (Src Host -> Dst Host)
                    List<Criterium> forwardCriteria = new ArrayList<>();
                    forwardCriteria.add(new Criterium("ETH_TYPE", null, "0x800"));
                    forwardCriteria.add(new Criterium("IPV4_SRC", srcHost + "/32", null));
                    forwardCriteria.add(new Criterium("IPV4_DST", dstHost + "/32", null));
                    Selector forwardSelector = new Selector(forwardCriteria);
                    Treatment forwardTreatment = new Treatment();
                    FlowObjective forwardFlow = new FlowObjective("SPECIFIC", 60606, 3000, false, targetSwitch, "ADD", forwardSelector, forwardTreatment);

                    // POST forward rule
                    target = client.target("http://localhost:8181/onos/v1/flowobjectives/" + targetSwitchForURL.toString() + "/forward?appId=77777");
                    Response forwardResponse = target.request(MediaType.APPLICATION_JSON_TYPE).post(Entity.json(forwardFlow));
                    System.out.println("pushRule: Forward rule POST executed for " + srcHost + " -> " + dstHost + ", status: " + forwardResponse.getStatus());
                }
            }
        }
        System.out.println("pushRule: Forward rules for all hosts completed.");
    }

    // Helper method to map multiple host IPs to the same switch (elementId)
    private static Map<String, String> mapHostToSwitch(List<String> ipAddresses, String elementId) {
        Map<String, String> map = new HashMap<>();
        for (String ip : ipAddresses) {
            map.put(ip, elementId);
        }
        return map;
    }
}