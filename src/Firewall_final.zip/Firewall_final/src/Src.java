/**
 * Created by student on 12/7/16.
 */
public class Src {

    private String port;
    private String device;

    /**
     *
     * @return
     * The port
     */
    public String getPort() {
        return port;
    }

    /**
     *
     * @param port
     * The port
     */
    public void setPort(String port) {
        this.port = port;
    }

    /**
     *
     * @return
     * The device
     */
    public String getDevice() {
        return device;
    }

    /**
     *
     * @param device
     * The device
     */
    public void setDevice(String device) {
        this.device = device;
    }

}
