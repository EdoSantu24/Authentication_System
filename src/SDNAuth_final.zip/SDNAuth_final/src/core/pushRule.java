
//Note: Updates 2018 (JSoler):
//
//  This application was originally created for previous versions of ONOS REST API and over previous versions of IntelliJ and Glassfish. There were some issues to run it, as the original code.
//  To overcome it the following has been done:
//  - ONOS REST API HAS CHANGED: It wass necessary to add the AppId in the target link for the flow-objective creation. See below within the code for details.
//  - A documented bug in Glassfish 4.1.1 caused the application to crash, when deserializing the answer to the POST into a POJO. This has been avoided by installing the newest version of the previous file "org.eclipse.persistence.moxy.jar".
//  - The different debuggin printouts can be read in Glassfish Log files, when running the application.
//

package core;

import pojo.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Collections;

import static java.lang.System.*;

import java.util.Map;
import java.util.logging.*;

/**
 * Created by student on 12/18/16.
 */
@WebServlet(name = "pushRule")
public class pushRule extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");

        // Fetch hosts information (Which device is connected to the logged host?)
        List<String> hostIPs = new ArrayList<>();
        // Map for host IP addresses to their associated elementId (switch ID)
        Map<String, String> hostIpToSwitchMap = new HashMap<>();  // Maps host IP to elementId (switch the host is connected)
        Client client = ClientBuilder.newClient().register(new Authenticator("onos", "rocks"));
        WebTarget target = client.target("http://localhost:8181/onos/v1/hosts");
        Response response1 = target.request().accept(MediaType.APPLICATION_JSON_TYPE).get();
        System.out.println(response1.getStatus());
        Hosts myhosts = response1.readEntity(Hosts.class);

        for (Host myhost : myhosts.getHosts()) {
            // Add host IPs to the list
            for (String ip : myhost.getIpAddresses()) {
                hostIPs.add(ip);
            }
            // Location is important because it contains the elementID of the device (switch) the host is connected to
            // --> it can be useful to make the code work with any topology as input
            // I had to create a new pojo class: Location to manage the locations with parameters elementId and Port
            if (myhost.getLocations() != null) { //location is a list because each host can be connected to multiple devices
                Location location = myhost.getLocations().get(0);
                hostIpToSwitchMap.putAll(mapHostToSwitch(myhost.getIpAddresses(), location.getElementId())); // Map all host IPs to their switch (elementId)
            }
        }

        // Sort the list of IP addresses to ensure consistent matching
        Collections.sort(hostIPs);

        // Prepare the mapping from host names (usernames: h1,h2,ecc...) to their corresponding IP
        Map<String, String> hostNameToIpMap = new HashMap<>();
        for (int i = 0; i < hostIPs.size(); i++) {
            String hostName = "h" + (i + 1);  // Create host names h1, h2, h3, ...
            hostNameToIpMap.put(hostName, hostIPs.get(i));  // Map host name to its IP
        }

        String targetSwitch = null;
        StringBuilder targetSwitchForURL = null;
        String inputHost = hostNameToIpMap.get(username);  // Get the IP corresponding to the input username

        if (inputHost == null || inputHost.isEmpty()) {
            System.out.println("pushRule: No host provided as input.");
            return;
        }
        System.out.println("pushRule: Input host is " + inputHost);

        // Determine the switch for the input host
        targetSwitch = hostIpToSwitchMap.get(inputHost);
        if (targetSwitch == null) {
            System.out.println("pushRule: No switch found for input host IP " + inputHost);
            return;
        }

        // Format the target switch for ONOS REST API
        targetSwitchForURL = new StringBuilder(targetSwitch);
        targetSwitchForURL.delete(2, 3); // Replace ":" with "%3A"
        targetSwitchForURL.insert(2, "%3A");

        // Iterate over all hosts to create forwarding rules
        client = ClientBuilder.newClient().register(new Authenticator("onos", "rocks"));

        for (String otherHost : hostIpToSwitchMap.keySet()) {
            if (!otherHost.equals(inputHost)) { // Skip the input host itself
                // Prepare forward rule (Input Host -> Other Host)
                List<Criterium> forwardCriteria = new ArrayList<>();
                forwardCriteria.add(new Criterium("ETH_TYPE", null, "0x800"));
                forwardCriteria.add(new Criterium("IPV4_SRC", inputHost + "/32", null));
                forwardCriteria.add(new Criterium("IPV4_DST", otherHost + "/32", null));
                Selector forwardSelector = new Selector(forwardCriteria);
                Treatment forwardTreatment = new Treatment();
                FlowObjective forwardFlow = new FlowObjective("SPECIFIC", 60606, 3000, false, targetSwitch, "REMOVE", forwardSelector, forwardTreatment);

                // POST forward rule
                target = client.target("http://localhost:8181/onos/v1/flowobjectives/" + targetSwitchForURL.toString() + "/forward?appId=77777");
                Response forwardResponse = target.request(MediaType.APPLICATION_JSON_TYPE).post(Entity.json(forwardFlow));
            }
        }

        System.out.println("pushRule: Forward rules for " + inputHost + " completed.");
        RequestDispatcher RequetsDispatcherObj = request.getRequestDispatcher("/index.jsp");
        RequetsDispatcherObj.forward(request, response);
    }

    // Helper method to map multiple host IPs to the same switch (elementId)
    private static Map<String, String> mapHostToSwitch(List<String> ipAddresses, String elementId) {
        Map<String, String> map = new HashMap<>();
        for (String ip : ipAddresses) {
            map.put(ip, elementId);
        }
        return map;
    }

}
