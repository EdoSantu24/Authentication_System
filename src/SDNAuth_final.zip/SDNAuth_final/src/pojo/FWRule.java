package pojo;

/**
 * Created by student on 12/18/16.
 */
public class FWRule {
    String h1;
    String h2;

    public FWRule() {
    }

    public FWRule(String h1, String h2) {
        super();
        this.h1 = h1;
        this.h2 = h2;
    }

    public String getH1() {
        return this.h1;
    }

    public String getH2() {
        return this.h2;
    }
}
