package pojo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Location implements Serializable {

    private String elementId;
    private String port;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 6378385279610038763L;

    // No-args constructor for use in serialization
    public Location() {
    }

    // Constructor with parameters
    public Location(String elementId, String port) {
        super();
        this.elementId = elementId;
        this.port = port;
    }

    // Getter and Setter methods
    public String getElementId() {
        return elementId;
    }

    public void setElementId(String elementId) {
        this.elementId = elementId;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}

