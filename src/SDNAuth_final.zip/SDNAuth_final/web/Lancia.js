const express = require('express'); //to do before running: import express module
const { Pool } = require('pg'); //to do before running: import pg module
const cors = require('cors');  //to do before running: Import the CORS module
const app = express();
const port = 3000;

// Enable CORS for all routes
app.use(cors()); // This will allow all origins to access the server

// Alternatively, you can specify a specific origin like so:
// app.use(cors({ origin: 'http://localhost:63342' }));

app.use(express.json());  // Middleware to parse JSON bodies

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'sdn_proj',
    password: 'ilovesdn',
    port: 5432,
});

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: "Please fill in all fields" });
    }

    try {
        const query = "SELECT us FROM users WHERE us = $1 AND psw = $2";
        const values = [username, password];
        const results = await pool.query(query, values);

        if (results.rows.length > 0) {
            const userId = results.rows[0].us;
            const updateQuery = "UPDATE users SET conn = true WHERE us = $1";
            await pool.query(updateQuery, [userId]);
            res.status(200).json({ message: "Login successful", userId });
        } else {
            res.status(401).json({ message: "Invalid username or password" });
        }
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err });
    }
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});